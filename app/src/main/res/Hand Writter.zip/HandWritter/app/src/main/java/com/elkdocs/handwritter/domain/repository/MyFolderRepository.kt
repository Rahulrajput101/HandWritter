package com.elkdocs.handwritter.domain.repository


import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages
import com.elkdocs.handwritter.domain.model.MyFolderModel
import com.elkdocs.handwritter.domain.model.MyPageModel

interface MyFolderRepository {

    suspend fun addMyFolder(myFolderModel: MyFolderModel) : Long

    suspend fun updateMyFolder(myFolderModel: MyFolderModel)


    suspend fun deleteMyFolder(myFolderModel: MyFolderModel)


    suspend fun getAllFolderWithPages(): List<FolderWithPages>


    suspend fun getMyFolder(id: Int): MyFolderModel


    suspend fun getMyFolderByName(folderName: String): MyFolderModel


    suspend fun addMyPage(myPageModel: MyPageModel) : Long
    suspend fun deleteMyPage(myPageModel: MyPageModel)

}