package com.elkdocs.handwritter.presentation.folder_screen

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages
import com.elkdocs.handwritter.databinding.ItemFolderListViewBinding

class FolderAdapter(
    private val folderListWithPages: List<FolderWithPages>
) : RecyclerView.Adapter<FolderAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderAdapter.MyViewHolder {
       return MyViewHolder.from(parent)
    }

    override fun onBindViewHolder(holder: FolderAdapter.MyViewHolder, position: Int) {
        holder.bind(folderListWithPages[position])
    }

    override fun getItemCount(): Int {
        return folderListWithPages.size
    }


    class MyViewHolder(private val binding : ItemFolderListViewBinding) : RecyclerView.ViewHolder(binding.root){

        companion object{
            fun from(parent: ViewGroup) : FolderAdapter.MyViewHolder {
                val inflater = LayoutInflater.from(parent.context)
                val binding = ItemFolderListViewBinding.inflate(inflater,parent,false)
                return MyViewHolder(binding)
            }
        }

        fun bind(folderWithPages: FolderWithPages){
            binding.tvFolderNameListView.text = folderWithPages.myFolderModel.folderName
            binding.tvFolderItemCountListView.text = folderWithPages.myFolderModel.pageCount
            binding.tvFolderLastUpdatedListView.text = folderWithPages.myFolderModel.lastUpdated
        }


    }
}