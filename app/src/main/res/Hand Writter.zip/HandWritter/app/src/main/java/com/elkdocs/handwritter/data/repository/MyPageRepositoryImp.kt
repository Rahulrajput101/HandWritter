package com.elkdocs.handwritter.data.repository

//import com.elkdocs.handwritter.data.data_source.MyPageDao
//import com.elkdocs.handwritter.domain.model.MyPageModel
//import com.elkdocs.handwritter.domain.repository.MyPageRepository
//
//class MyPageRepositoryImp(
//    private val dao : MyPageDao
//) : MyPageRepository{
//    override suspend fun addMyPage(myPageModel: MyPageModel): Long {
//        return dao.addMyPage(myPageModel)
//    }
//
//    override suspend fun deleteMyPage(myPageModel: MyPageModel) {
//        dao.deleteMyPage(myPageModel)
//    }
//}