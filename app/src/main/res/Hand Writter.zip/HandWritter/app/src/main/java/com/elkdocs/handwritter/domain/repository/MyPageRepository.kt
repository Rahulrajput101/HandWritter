package com.elkdocs.handwritter.domain.repository

import com.elkdocs.handwritter.domain.model.MyPageModel

//interface MyPageRepository {
//
//    suspend fun addMyPage(myPageModel: MyPageModel) : Long
//    suspend fun deleteMyPage(myPageModel: MyPageModel)
//
//}