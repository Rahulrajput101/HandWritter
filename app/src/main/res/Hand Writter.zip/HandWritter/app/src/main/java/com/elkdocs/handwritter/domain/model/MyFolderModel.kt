package com.elkdocs.handwritter.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "my_folders")
data class MyFolderModel(
    @PrimaryKey(autoGenerate = true)
    val folderId: Int,
    val folderName: String,
    val folderIcon: String,
    val pageCount: String,
    val lastUpdated: String
)
