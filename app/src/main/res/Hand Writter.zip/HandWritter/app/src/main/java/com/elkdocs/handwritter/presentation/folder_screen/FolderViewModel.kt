package com.elkdocs.handwritter.presentation.folder_screen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.elkdocs.handwritter.domain.use_cases.GetFolderWithPages
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

@HiltViewModel
class FolderViewModel @Inject constructor(
    val getFolderWithPages: GetFolderWithPages
) : ViewModel() {

    private val _state = MutableStateFlow(FolderState())
    val state : StateFlow<FolderState> = _state

   init {
       getFolderListWithPages()
   }

    private var getFolderJob : Job? = null

    private fun getFolderListWithPages(){
       getFolderJob?.cancel()
        getFolderWithPages().onEach {
            _state.value = FolderState(it)
        }.launchIn(viewModelScope)
    }


}