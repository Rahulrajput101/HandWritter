package com.elkdocs.handwritter.data.data_source

import androidx.room.*
import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages
import com.elkdocs.handwritter.domain.model.MyFolderModel
import com.elkdocs.handwritter.domain.model.MyPageModel

@Dao
interface MyFolderDao {

    @Upsert
    suspend fun addMyFolder(myFolderModel: MyFolderModel) : Long

    @Delete
    suspend fun deleteMyFolder(myFolderModel: MyFolderModel)

    @Query("SELECT * FROM my_folders")
    suspend fun getAllFolderWithPages(): List<FolderWithPages>

    @Query("SELECT * FROM my_folders WHERE id = :id")
    suspend fun getMyFolder(id: Int): MyFolderModel

    @Query("SELECT * FROM my_folders WHERE folder_name = :folderName")
    suspend fun getMyFolderByName(folderName: String): MyFolderModel


    @Upsert
    suspend fun addMyPage(myPageModel: MyPageModel) : Long

    @Delete
    suspend fun deleteMyPage(myPageModel: MyPageModel)

    @Query("SELECT * FROM my_image WHERE id = :id")
    suspend fun getAllPages(id: Int): List<MyPageModel>

}