package com.elkdocs.handwritter.domain.use_cases

import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages
import com.elkdocs.handwritter.domain.repository.MyFolderRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Named

class GetFolderWithPages @Inject constructor(
    @Named("myFolderRepository")private val repository: MyFolderRepository
) {
    operator fun invoke() : Flow<List<FolderWithPages>> = flow{
        try{
            emit(repository.getAllFolderWithPages())
        }catch (e : Exception){
            emit(emptyList())
        }
    }
}