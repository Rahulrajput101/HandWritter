package com.elkdocs.handwritter.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "my_pages")
data class MyPageModel(
    @PrimaryKey(autoGenerate = true)
    val pageId: Int,
    val folderId: Int,
    val uriIndex: Int,
    val notesText: String,
    val fontStyle: Int,
    val fontSize: String,
    val charSpace: String,
    val wordSpace: String,
    val addHrLines: String,
    val addVrLines: String,
    val lineColor: String
)
