package com.elkdocs.handwritter.presentation.folder_screen

import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages

data class FolderState(
    val folderListWithPages : List<FolderWithPages> = emptyList()
)
