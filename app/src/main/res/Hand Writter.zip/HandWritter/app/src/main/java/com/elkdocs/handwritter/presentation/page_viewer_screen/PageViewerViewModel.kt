package com.elkdocs.handwritter.presentation.page_viewer_screen

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel

@HiltViewModel
class PageViewerViewModel : ViewModel() {
}