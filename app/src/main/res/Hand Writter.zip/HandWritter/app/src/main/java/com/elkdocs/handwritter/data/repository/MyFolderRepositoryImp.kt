package com.elkdocs.handwritter.data.repository

import com.elkdocs.handwritter.data.data_source.MyFolderDao
import com.elkdocs.handwritter.data.data_source.entity.FolderWithPages
import com.elkdocs.handwritter.domain.model.MyFolderModel
import com.elkdocs.handwritter.domain.model.MyPageModel
import com.elkdocs.handwritter.domain.repository.MyFolderRepository

class MyFolderRepositoryImp(
    private val myFolderDao: MyFolderDao,
) : MyFolderRepository {
    override suspend fun addMyFolder(myFolderModel: MyFolderModel) : Long{
        return myFolderDao.addMyFolder(myFolderModel)
    }

    override suspend fun updateMyFolder(myFolderModel: MyFolderModel) {
        TODO("Not yet implemented")
    }

    override suspend fun deleteMyFolder(myFolderModel: MyFolderModel) {
    }

    override suspend fun getAllFolderWithPages(): List<FolderWithPages> {
        return myFolderDao.getAllFolderWithPages()
    }

    override suspend fun getMyFolder(id: Int): MyFolderModel {
        TODO("Not yet implemented")
    }

    override suspend fun getMyFolderByName(folderName: String): MyFolderModel {
        TODO("Not yet implemented")
    }




    override suspend fun addMyPage(myPageModel: MyPageModel): Long {
        return myFolderDao.addMyPage(myPageModel)
    }

    override suspend fun deleteMyPage(myPageModel: MyPageModel) {
        myFolderDao.deleteMyPage(myPageModel)
    }


}